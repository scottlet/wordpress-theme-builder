<?php addBannerImage(null, null, false, true);?>
<div class="constrain">
    <div class="vcenter">
        <h3><?php the_title()?></h3>
        <?php the_content(); ?>
    </div>
</div>

