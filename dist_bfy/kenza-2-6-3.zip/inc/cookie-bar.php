<div class="cookie-warning invert">
    <div class="inner">
        <p>
            <small>
                <?php dynamic_sidebar('kenza_cookie_bar'); ?>
            </small>
        </p>
        <button data-action="hide-banner" class="cta">
            Accept
        </button>
    </div>
</div>