<?php $content = \ojoho\get_dynamic_sidebar($sidebar);

if (!empty($content)) {
    echo $content;
}
